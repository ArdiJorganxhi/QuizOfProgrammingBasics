//
//  QuizAppApp.swift
//  QuizApp
//
//  Created by Ardi Jorganxhi on 21.11.22.
//

import SwiftUI

@main
struct QuizAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
