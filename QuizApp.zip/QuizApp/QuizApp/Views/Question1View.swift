//
//  Question1View.swift
//  QuizApp
//
//  Created by Ardi Jorganxhi on 21.11.22.
//

import SwiftUI


struct selectionTab {
    
    @State var selectionTab = 1
}

struct QuestionView: View {
    
    

    let question: String
    let answer1: String
    let answer2: String
    let answer3: String
    let answer4: String
    
    var body: some View{
        
        
        
        VStack(spacing: 60){
            
            
            Spacer()
            Text(question)
                .font(.title).bold()
    
            
            
            VStack(spacing: 35){
                
              
                
                Button(action: {
                    
                    print("Hello World")
                    
                }, label: {
                    Text(answer1)
                        .foregroundColor(Color.black)
                }).padding(.vertical, 10.0)
                    .padding(.horizontal)
                    .frame(width: 300)
                    .border(Color.black, width: 2)
                    
                Button(action: {
                    selectionTab().selectionTab += 1
                }, label: {
                    Text(answer2)
                        .foregroundColor(Color.black)
                }).padding(.vertical, 10.0)
                    .padding(.horizontal)
                    .frame(width: 300)
                    .border(Color.black, width: 2)
                Button(action: {
                    selectionTab().selectionTab += 1
                }, label: {
                    Text(answer3)
                        .foregroundColor(Color.black)
                }).padding(.vertical, 10.0)
                    .padding(.horizontal)
                    .frame(width: 300)
                    .border(Color.black, width: 2)
                
                
                Button(action: {
                    selectionTab().selectionTab += 1
                }, label: {
                    Text(answer4)
                        .foregroundColor(Color.black)
                }).padding(.vertical, 10.0)
                    .padding(.horizontal)
                    .frame(width: 300)
                    .border(Color.black, width: 2)
                
            }
            
                
                
           Spacer()
           
            
        }
    }
}



struct Question1View: View {
    
    
    @State var selectTab:String = "One"
    
    var body: some View {
        
        
        TabView(selection: $selectTab){
            
            QuestionView(question: "What is Java?", answer1: "Java is a programming language", answer2: "Java is a browser", answer3: "Java is an operating system", answer4: "Java is a hardware part of PC")
                .tag("One")
            
            QuestionView(question: "What is C++?", answer1: "C++ is a programming language", answer2: "C++ is a browser", answer3: "C++ is an operating system", answer4: "C++ is a hardware part of PC")
                
                .tag("Two")
            
            QuestionView(question: "What is C?", answer1: "C is a programming language", answer2: "C is a browser", answer3: "C is an operating system", answer4: "C is a hardware part of PC")
                
                .tag(3)
            
        }
       
    }
}

struct Question1View_Previews: PreviewProvider {
    static var previews: some View {
        Question1View()
    }
}
